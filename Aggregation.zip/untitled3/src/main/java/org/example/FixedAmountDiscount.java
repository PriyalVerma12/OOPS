package org.example;

public class FixedAmountDiscount extends Discount {
    public double amount;

    public FixedAmountDiscount(String code, String description, double amount) {
        super(code, description);
        this.amount = amount;
    }

    public double applyTo(double price) {
        double result = price - amount;
        return result < 0 ? 0 : result;
    }
}
