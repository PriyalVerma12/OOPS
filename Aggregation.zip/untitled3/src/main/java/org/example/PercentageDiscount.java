package org.example;

public class PercentageDiscount extends Discount {
    public double percent;

    public PercentageDiscount(String code, String description, double percent) {
        super(code, description);
        this.percent = percent;
    }

    public double applyTo(double price) {
        return price * (1 - percent / 100);
    }
}
