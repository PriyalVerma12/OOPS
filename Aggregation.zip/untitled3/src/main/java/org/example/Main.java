package org.example;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


public class Main {
    public static void main(String[] args) {
        PercentageDiscount fifteenOff = new PercentageDiscount("SAVE15","15% OFF", 15 );
        FixedAmountDiscount tenOff =new FixedAmountDiscount("SAVE10","10% OFF", 10 );
        System.out.println(fifteenOff.code + ": $100 becomes $" + fifteenOff.applyTo(100));
        System.out.println(tenOff.code + ": $100 becomes $" + tenOff.applyTo(100));
    }

}

