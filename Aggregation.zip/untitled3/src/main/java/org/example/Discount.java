package org.example;

public abstract class Discount {
    public String code;
    public String description;

    public Discount(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
